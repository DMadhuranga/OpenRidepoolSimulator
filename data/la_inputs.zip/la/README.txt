LA input data for OpenRidepoolSimulator
========================================

Unpack this archive so the city directory sits where DATAROOT will point.
From the repository root:

    unzip data/la_inputs.zip -d data/      ->  data/la/...

CONTENTS

  map/edges.csv            directed road graph, "origin,dest,travel_time"
                           (1-based node ids, 212432 edges, 76531 nodes)
  map/nodes.csv            node coordinates; reference only, the simulator
                           never reads this file
  requests/requests.csv    47006 direct (non-transit) requests
  requests/leg_requests.csv
                           100017 first/last-mile transit legs, used when
                           ALLOW_MULTI_MODAL is true
  vehicles/vehicles.csv    10000 vehicles; VEHICLE_LIMIT caps how many load

NOT INCLUDED: map/times.npy

The simulator reads map/times.npy, a dense 76531 x 76531 uint16
all-pairs travel-time matrix (11.7 GB).  It is derived data -- the
all-pairs shortest paths over map/edges.csv -- so it is generated rather than
shipped:

    python3 data/gen_times_npy.py data/la --jobs 8

Needs numpy and scipy.  Without it the simulator aborts in Network::Network
at "map/times.npy".
